import math
import heapq
from PyQt5.QtWidgets import (
    QAction,
    QInputDialog,
    QMessageBox,
    QDialog,
    QVBoxLayout,
    QFormLayout,
    QComboBox,
    QDialogButtonBox,
    QLabel,
    QTabWidget,
    QWidget,
    QDoubleSpinBox,
)
from PyQt5.QtGui import QIcon, QColor
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsPointXY,
    QgsSpatialIndex,
    QgsCoordinateTransform,
    QgsGeometry,
)
from qgis.gui import QgsMapToolEmitPoint, QgsVertexMarker
from qgis.utils import iface

# Конфигурация имен слоев и их обязательности
CONFIG = {
    "EDGE_UDS": {"name": "УДС_link", "required": True},
    "NODE_UDS": {"name": "Узлы_node", "required": False},
    "BUS_STOP": {"name": "ООТ_stoppoint_stoppoint", "required": False},
    "BUILDING": {"name": "Здания_насел_attract", "required": False},
    "SRTM_LINE": {"name": "SRTM_Irkutsk_Lines_Interval 5", "required": False},
}


class RouterSettingsDialog(QDialog):
    # Диалог настройки параметров роутинга
    def __init__(self, router, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Настройки роутера")
        self.resize(500, 400)
        self.router = router

        self.layer = self.router.layers.get("EDGE_UDS")
        self.field_names = [f.name() for f in self.layer.fields()] if self.layer else []
        self.field_names.insert(0, "")

        # Инициализация вкладок UI
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tab_fields = QWidget()
        self.tab_params = QWidget()

        self.tabs.addTab(self.tab_fields, "Поля данных")
        self.tabs.addTab(self.tab_params, "Параметры")

        # Вкладка маппинга полей
        fields_layout = QFormLayout(self.tab_fields)

        self.combo_car_fwd = QComboBox()
        self.combo_car_fwd.addItems(self.field_names)
        self.combo_car_bwd = QComboBox()
        self.combo_car_bwd.addItems(self.field_names)

        self.combo_foot = QComboBox()
        self.combo_foot.addItems(self.field_names)
        self.combo_bike = QComboBox()
        self.combo_bike.addItems(self.field_names)

        self._set_combo(
            self.combo_car_fwd, self.router.field_speed_fwd, ["V0PRT", "SPEED_FWD"]
        )
        self._set_combo(
            self.combo_car_bwd, self.router.field_speed_bwd, ["R_V0PRT", "SPEED_BWD"]
        )
        self._set_combo(
            self.combo_foot, self.router.field_speed_foot, ["FOOT_SPEED", "WALK"]
        )
        self._set_combo(
            self.combo_bike, self.router.field_speed_bike, ["BIKE_SPEED", "CYCLE"]
        )

        fields_layout.addRow(QLabel("<b>Авто (Туда):</b>"), self.combo_car_fwd)
        fields_layout.addRow(QLabel("<b>Авто (Обратно):</b>"), self.combo_car_bwd)
        fields_layout.addRow(QLabel("---"), QLabel("---"))
        fields_layout.addRow(QLabel("<b>Пешеход (опц.):</b>"), self.combo_foot)
        fields_layout.addRow(QLabel("<b>Велосипед (опц.):</b>"), self.combo_bike)

        # Вкладка параметров скорости по умолчанию
        params_layout = QFormLayout(self.tab_params)

        self.spin_default_walk = QDoubleSpinBox()
        self.spin_default_walk.setRange(1, 20)
        self.spin_default_walk.setValue(self.router.default_walk_speed)
        self.spin_default_walk.setSuffix(" км/ч")

        self.spin_default_bike = QDoubleSpinBox()
        self.spin_default_bike.setRange(1, 60)
        self.spin_default_bike.setValue(self.router.default_bike_speed)
        self.spin_default_bike.setSuffix(" км/ч")

        params_layout.addRow(QLabel("База Пешеход:"), self.spin_default_walk)
        params_layout.addRow(QLabel("База Велосипед:"), self.spin_default_bike)
        params_layout.addRow(
            QLabel(
                "<i>Примечание: Для авто дефолтов нет, <br>строго используются данные из полей.</i>"
            ),
            QLabel(""),
        )

        layout.addWidget(self.tabs)

        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)

    # Установка текущего значения в комбобокс
    def _set_combo(self, combo, current_val, defaults):
        if current_val and current_val in self.field_names:
            combo.setCurrentText(current_val)
            return
        for d in defaults:
            idx = combo.findText(d)
            if idx != -1:
                combo.setCurrentIndex(idx)
                return

    # Сохранение настроек в объект роутера
    def save_settings(self):
        cf = self.combo_car_fwd.currentText()
        cb = self.combo_car_bwd.currentText()
        ff = self.combo_foot.currentText()
        bf = self.combo_bike.currentText()

        cf = cf if cf else None
        cb = cb if cb else None
        ff = ff if ff else None
        bf = bf if bf else None

        changed = (
            cf != self.router.field_speed_fwd
            or cb != self.router.field_speed_bwd
            or ff != self.router.field_speed_foot
            or bf != self.router.field_speed_bike
        )

        # Сброс графа при изменении полей
        if changed:
            self.router.graph_built = False
            iface.messageBar().pushMessage(
                "Настройки", "Поля изменены. Граф будет перестроен.", level=1
            )

        self.router.set_fields(cf, cb, ff, bf)
        self.router.default_walk_speed = self.spin_default_walk.value()
        self.router.default_bike_speed = self.spin_default_bike.value()


class RouteMapTool(QgsMapToolEmitPoint):
    # Инструмент карты для выбора точек старта и финиша
    def __init__(self, canvas, router):
        self.canvas = canvas
        self.router = router
        QgsMapToolEmitPoint.__init__(self, self.canvas)
        self.start_point = None
        self.markers = []

    def deactivate(self):
        self.reset_markers()
        super().deactivate()

    # Удаление маркеров с карты
    def reset_markers(self):
        for m in self.markers:
            try:
                self.canvas.scene().removeItem(m)
            except:
                pass
        self.markers = []
        self.canvas.refresh()

    # Обработка клика по карте
    def canvasReleaseEvent(self, event):
        point_canvas = self.toMapCoordinates(event.pos())

        edge_layer = self.router.layers.get("EDGE_UDS")
        if not edge_layer:
            iface.messageBar().pushMessage("Ошибка", "Слой УДС не найден", level=3)
            return

        # Трансформация координат
        layer_crs = edge_layer.crs()
        project_crs = QgsProject.instance().crs()
        transform = QgsCoordinateTransform(
            project_crs, layer_crs, QgsProject.instance()
        )
        point_layer = transform.transform(point_canvas)

        # Логика выбора точек: первая - старт, вторая - финиш и расчет
        if self.start_point is None:
            self.reset_markers()
            self.start_point = point_layer
            self.add_marker(point_canvas, QColor(0, 200, 0))
            iface.messageBar().pushMessage("Старт", "Точка старта выбрана", level=1)
        else:
            end_point = point_layer
            self.add_marker(point_canvas, QColor(200, 0, 0))

            items = ["Автомобиль", "Пешеход", "Велосипед"]
            item, ok = QInputDialog.getItem(
                iface.mainWindow(), "Выбор", "Транспорт:", items, 0, False
            )

            if ok and item:
                mode_map = {"Пешеход": "foot", "Велосипед": "bike", "Автомобиль": "car"}
                selected_mode = mode_map[item]

                try:
                    path_geoms, time_min = self.router.dijkstra(
                        self.start_point, end_point, mode=selected_mode
                    )
                    if path_geoms:
                        self.router.visualize_result(
                            path_geoms, selected_mode, time_min
                        )
                except Exception as e:
                    iface.messageBar().pushMessage("Ошибка", f"{e}", level=3)

            self.start_point = None

    # Добавление визуального маркера
    def add_marker(self, point, color):
        m = QgsVertexMarker(self.canvas)
        m.setCenter(point)
        m.setColor(color)
        m.setIconType(QgsVertexMarker.ICON_X)
        m.setIconSize(10)
        m.setPenWidth(3)
        self.markers.append(m)


class NativeQgisRouter:
    # Основной класс логики маршрутизации
    def __init__(self):
        self.project = QgsProject.instance()
        self.layers = {}
        self.graph = {}
        self.nodes_z = {}
        self.crs_authid = "EPSG:4326"
        self.graph_built = False
        self.field_speed_fwd = None
        self.field_speed_bwd = None
        self.field_speed_foot = None
        self.field_speed_bike = None
        self.default_walk_speed = 5.0
        self.default_bike_speed = 15.0

    def set_fields(self, fwd, bwd, foot, bike):
        self.field_speed_fwd = fwd
        self.field_speed_bwd = bwd
        self.field_speed_foot = foot
        self.field_speed_bike = bike

    # Загрузка слоев из проекта
    def load_layers(self):
        missing = []
        self.layers = {}
        for key, info in CONFIG.items():
            found = self.project.mapLayersByName(info["name"])
            if not found:
                if info["required"]:
                    missing.append(info["name"])
            else:
                self.layers[key] = found[0]

        if missing:
            raise Exception(f"Не найдены слои: {', '.join(missing)}")

        self.crs_authid = self.layers["EDGE_UDS"].crs().authid()

    # Генерация строкового ключа для узла
    def _get_key(self, point):
        return f"{point.x():.5f}_{point.y():.5f}"

    # Получение высоты точки из слоя SRTM
    def get_elevation_for_point(self, point, srtm_layer, spatial_index):
        if not spatial_index or not srtm_layer:
            return 0.0

        tr = QgsCoordinateTransform(
            self.layers["EDGE_UDS"].crs(), srtm_layer.crs(), QgsProject.instance()
        )
        pt_tr = tr.transform(point)

        nearest = spatial_index.nearestNeighbor(pt_tr, 1)
        if not nearest:
            return 0.0
        feat = srtm_layer.getFeature(nearest[0])
        for f in feat.fields():
            if f.typeName() in ["Integer", "Real", "Double"]:
                return float(feat[f.name()])
        return 0.0

    # Безопасный парсинг скорости из атрибута
    def _parse_speed(self, value):
        if value is None:
            return 0.0
        if isinstance(value, (int, float)):
            return float(value)
        try:
            return float(
                str(value).lower().replace("km/h", "").replace(",", ".").strip()
            )
        except:
            return 0.0

    # Построение дорожного графа
    def build_graph(self):
        if not self.field_speed_fwd or not self.field_speed_bwd:
            raise Exception("Поля скорости Авто не выбраны! Зайдите в настройки.")

        iface.messageBar().pushMessage("Роутер", "Построение графа...", level=0)

        edge_layer = self.layers["EDGE_UDS"]
        srtm_layer = self.layers.get("SRTM_LINE")
        srtm_index = QgsSpatialIndex(srtm_layer.getFeatures()) if srtm_layer else None

        idx_fwd = edge_layer.fields().indexOf(self.field_speed_fwd)
        idx_bwd = edge_layer.fields().indexOf(self.field_speed_bwd)

        idx_foot = (
            edge_layer.fields().indexOf(self.field_speed_foot)
            if self.field_speed_foot
            else -1
        )
        idx_bike = (
            edge_layer.fields().indexOf(self.field_speed_bike)
            if self.field_speed_bike
            else -1
        )

        features = edge_layer.getFeatures()
        count = 0
        self.graph = {}
        self.nodes_z = {}

        # Итерация по ребрам графа
        for feat in features:
            geom = feat.geometry()
            if not geom:
                continue

            if geom.isMultipart():
                lines = geom.asMultiPolyline()
            else:
                lines = [geom.asPolyline()]

            raw_v_fwd = feat.attributes()[idx_fwd] if idx_fwd != -1 else 0
            raw_v_bwd = feat.attributes()[idx_bwd] if idx_bwd != -1 else 0

            val_foot = (
                self._parse_speed(feat.attributes()[idx_foot]) if idx_foot != -1 else 0
            )
            val_bike = (
                self._parse_speed(feat.attributes()[idx_bike]) if idx_bike != -1 else 0
            )

            speed_fwd = self._parse_speed(raw_v_fwd)
            speed_bwd = self._parse_speed(raw_v_bwd)

            for line_points in lines:
                if len(line_points) < 2:
                    continue

                start_pt = line_points[0]
                end_pt = line_points[-1]

                u_key = self._get_key(start_pt)
                v_key = self._get_key(end_pt)

                # Кеширование высот узлов
                if u_key not in self.nodes_z:
                    self.nodes_z[u_key] = self.get_elevation_for_point(
                        start_pt, srtm_layer, srtm_index
                    )
                if v_key not in self.nodes_z:
                    self.nodes_z[v_key] = self.get_elevation_for_point(
                        end_pt, srtm_layer, srtm_index
                    )

                length_m = geom.length()
                rise = self.nodes_z[v_key] - self.nodes_z[u_key]
                slope = rise / length_m if length_m > 0 else 0

                if u_key not in self.graph:
                    self.graph[u_key] = []
                if v_key not in self.graph:
                    self.graph[v_key] = []

                safe_geom = QgsGeometry(geom)

                base_data = {
                    "length": length_m,
                    "geom": safe_geom,
                    "foot_attr": val_foot,
                    "bike_attr": val_bike,
                }

                # Прямое направление
                d_fwd = base_data.copy()
                d_fwd["slope"] = slope
                d_fwd["car_speed"] = speed_fwd
                self.graph[u_key].append((v_key, d_fwd))

                # Обратное направление
                d_bwd = base_data.copy()
                d_bwd["slope"] = -slope
                d_bwd["car_speed"] = speed_bwd
                self.graph[v_key].append((u_key, d_bwd))

            count += 1
            if count % 5000 == 0:
                iface.messageBar().pushMessage(
                    "Граф", f"Обработано {count}...", level=0
                )

        self.graph_built = True
        iface.messageBar().pushMessage(
            "Роутер", "Граф (направленный) построен.", level=1
        )

    # Расчет веса ребра (времени) в зависимости от режима
    def calculate_weight(self, data, mode):
        length_m = data["length"]
        slope = data["slope"]

        speed_kmh = 5.0

        if length_m == 0:
            return 0.0

        if mode == "car":
            speed_kmh = data["car_speed"]
            if speed_kmh <= 0:
                return float("inf")

        elif mode == "foot":
            if data["foot_attr"] > 0:
                speed_kmh = data["foot_attr"]
            else:
                base = self.default_walk_speed
                # Функция Тоблера для пешеходов
                tobler_val = 6 * math.exp(-3.5 * abs(slope + 0.05))
                factor = tobler_val / 6.0
                speed_kmh = base * factor
                speed_kmh = max(0.1, speed_kmh)

        elif mode == "bike":
            if data["bike_attr"] > 0:
                speed_kmh = data["bike_attr"]
            else:
                base = self.default_bike_speed
                # Упрощенная модель влияния уклона на велосипед
                if slope > 0:
                    factor = max(0.1, 1.0 - (slope * 10))
                    speed_kmh = base * factor
                else:
                    factor = 1.0 + (abs(slope) * 5)
                    speed_kmh = min(60.0, base * factor)

        return (length_m / 1000.0) / speed_kmh * 60.0

    # Поиск ближайшего узла графа к точке
    def find_nearest_node(self, point):
        min_dist = float("inf")
        nearest = None
        for key in self.nodes_z.keys():
            try:
                x, y = map(float, key.split("_"))
                pt = QgsPointXY(x, y)
                dist = point.sqrDist(pt)
                if dist < min_dist:
                    min_dist = dist
                    nearest = key
            except:
                continue

        if min_dist > (500 * 500):
            return None
        return nearest

    # Алгоритм Дейкстры
    def dijkstra(self, start_pt, end_pt, mode="foot"):
        if not self.graph_built:
            return None, 0

        start_node = self.find_nearest_node(start_pt)
        end_node = self.find_nearest_node(end_pt)

        if not start_node or not end_node:
            iface.messageBar().pushMessage(
                "Ошибка", "Точки слишком далеко от графа", level=3
            )
            return None, 0

        pq = [(0, start_node, [])]
        visited = set()
        min_costs = {start_node: 0}

        final_path_geoms = []
        final_cost = 0

        while pq:
            cost, u, path = heapq.heappop(pq)

            if u == end_node:
                final_cost = cost
                final_path_geoms = path
                break

            if u in visited:
                continue
            visited.add(u)

            for v, data in self.graph.get(u, []):
                if v in visited:
                    continue

                weight = self.calculate_weight(data, mode)
                if weight == float("inf"):
                    continue

                new_cost = cost + weight

                if new_cost < min_costs.get(v, float("inf")):
                    min_costs[v] = new_cost
                    new_path = path + [data["geom"]]
                    heapq.heappush(pq, (new_cost, v, new_path))

        if not final_path_geoms:
            iface.messageBar().pushMessage(
                "Ошибка", f"Путь не найден ({mode})", level=3
            )
            return None, 0

        iface.messageBar().pushMessage("УСПЕХ", f"Время: {final_cost:.2f} мин", level=1)
        return final_path_geoms, final_cost

    # Визуализация маршрута временным слоем
    def visualize_result(self, geoms, mode, time_min):
        uri = f"LineString?crs={self.crs_authid}"
        layer_name = f"Маршрут ({mode})"

        old_layers = QgsProject.instance().mapLayersByName(layer_name)
        if old_layers:
            QgsProject.instance().removeMapLayer(old_layers[0])

        vl = QgsVectorLayer(uri, layer_name, "memory")
        pr = vl.dataProvider()
        feats = []
        for g in geoms:
            f = QgsFeature()
            f.setGeometry(g)
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()

        symbol = vl.renderer().symbol()
        if mode == "foot":
            symbol.setColor(QColor("blue"))
            symbol.setWidth(1.0)
        elif mode == "bike":
            symbol.setColor(QColor("green"))
            symbol.setWidth(1.5)
        elif mode == "car":
            symbol.setColor(QColor("red"))
            symbol.setWidth(2.5)

        QgsProject.instance().addMapLayer(vl)
        iface.mapCanvas().refresh()


class NativeRouterPlugin:
    # Класс интеграции плагина в QGIS
    def __init__(self, iface):
        self.iface = iface
        self.router = NativeQgisRouter()
        self.map_tool = None
        self.act_run = None
        self.act_set = None

    # Инициализация GUI
    def initGui(self):
        self.act_run = QAction(QIcon(), "Построить маршрут", self.iface.mainWindow())
        self.act_run.triggered.connect(self.run_tool)
        self.act_set = QAction(QIcon(), "Настройки роутера", self.iface.mainWindow())
        self.act_set.triggered.connect(self.open_settings)

        self.iface.addToolBarIcon(self.act_run)
        self.iface.addToolBarIcon(self.act_set)
        self.iface.addPluginToMenu("&Native Router", self.act_run)
        self.iface.addPluginToMenu("&Native Router", self.act_set)

    # Открытие диалога настроек
    def open_settings(self):
        try:
            if not self.router.layers:
                self.router.load_layers()
            dlg = RouterSettingsDialog(self.router, self.iface.mainWindow())
            if dlg.exec_() == QDialog.Accepted:
                dlg.save_settings()
        except Exception as e:
            QMessageBox.critical(None, "Error", str(e))

    # Запуск инструмента маршрутизации
    def run_tool(self):
        try:
            if not self.router.layers:
                self.router.load_layers()
            if not self.router.field_speed_fwd:
                self.open_settings()
                if not self.router.field_speed_fwd:
                    return

            if not self.router.graph_built:
                self.router.build_graph()

            if not self.map_tool:
                self.map_tool = RouteMapTool(self.iface.mapCanvas(), self.router)
            self.iface.mapCanvas().setMapTool(self.map_tool)
            iface.messageBar().pushMessage("Инфо", "Выберите точки на карте", level=1)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"{e}")
            self.unload()

    # Выгрузка плагина
    def unload(self):
        if self.map_tool:
            self.iface.mapCanvas().unsetMapTool(self.map_tool)
            self.map_tool.deactivate()
        if self.act_run:
            self.iface.removePluginMenu("&Native Router", self.act_run)
            self.iface.removeToolBarIcon(self.act_run)
        if self.act_set:
            self.iface.removePluginMenu("&Native Router", self.act_set)
            self.iface.removeToolBarIcon(self.act_set)
