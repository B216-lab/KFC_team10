"""
Инициализатор плагина. Этот модуль вызывается QGIS при загрузке плагина.
"""

def classFactory(iface):
    """
    Создает экземпляр основного класса плагина.

    :param iface: Ссылка на интерфейс QGIS.
    :type iface: QgsInterface
    """
    # Импортируем основной класс из mainPlugin.py
    from .mainPlugin import NativeRouterPlugin
    return NativeRouterPlugin(iface)