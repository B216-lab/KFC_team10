import math
import time
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsSpatialIndex,
    QgsRectangle,
    QgsGraduatedSymbolRenderer,
    QgsRendererRange,
    QgsSymbol,
    QgsFeatureRequest,
    QgsPointXY,
    QgsColorRampShader,
)
from PyQt5.QtCore import QVariant
from PyQt5.QtGui import QColor, QIcon
from PyQt5.QtWidgets import QAction, QMessageBox
from qgis.utils import iface

# Конфигурация параметров модели и имен слоев
CFG = {
    "layer_buildings": "Здания_насел_attract",
    "layer_parking": "парковки хакатон",
    "field_cap": "Колич",
    "field_pop": "Насел",
    "field_job": "att_mn",
    "radius": 400.0,
    "decay_param": 4.0,
    "auto_rate_res": 0.35,
    "auto_rate_job": 0.20,
    "stay_home_rate": 0.40,
    "use_manhattan": False,
}


class ProfessionalParking:
    # Класс реализации логики расчета обеспеченности
    def __init__(self, cfg):
        self.cfg = cfg

    # Логирование сообщений в интерфейс QGIS или консоль
    def log(self, msg: str, level: int = 0):
        if iface:
            iface.messageBar().pushMessage("Parking Model", msg, level=level)
        else:
            print(f"[Parking] {msg}")

    # Получение слоя по имени
    def get_layer(self, name: str) -> QgsVectorLayer:
        layers = QgsProject.instance().mapLayersByName(name)
        return layers[0] if layers else None

    # Функция затухания веса в зависимости от расстояния (экспоненциальная)
    def decay_function(self, distance: float) -> float:
        if distance > self.cfg["radius"]:
            return 0.0
        return math.exp(
            -((distance / self.cfg["radius"]) ** 2) * self.cfg["decay_param"]
        )

    # Расчет расстояния (Евклидово или Манхэттенское)
    def get_distance(self, p1: QgsPointXY, p2: QgsPointXY) -> float:
        if self.cfg["use_manhattan"]:
            return abs(p1.x() - p2.x()) + abs(p1.y() - p2.y())
        else:
            return math.sqrt((p1.x() - p2.x()) ** 2 + (p1.y() - p2.y()) ** 2)

    # Основной метод запуска расчета
    def run(self):
        start_t = time.time()

        b_layer = self.get_layer(self.cfg["layer_buildings"])
        p_layer = self.get_layer(self.cfg["layer_parking"])

        # Проверка наличия входных слоев
        if not b_layer or not p_layer:
            self.log(
                f"ERROR: Layers not found: '{self.cfg['layer_buildings']}' or '{self.cfg['layer_parking']}'.",
                level=3,
            )
            return

        self.log("Starting generation of resident and business layers...")
        crs = b_layer.crs().authid()
        geom_type = "Polygon" if b_layer.geometryType() == 2 else "Point"

        # Создание временного слоя результатов (Жители/Ночь)
        layer_res = QgsVectorLayer(
            f"{geom_type}?crs={crs}", "Результат_ЖИТЕЛИ_Ночь", "memory"
        )
        pr_res = layer_res.dataProvider()
        pr_res.addAttributes(
            [
                QgsField("Demand_Res", QVariant.Double),
                QgsField("Index_Res", QVariant.Double),
                QgsField("Status", QVariant.String),
            ]
        )
        layer_res.updateFields()

        # Создание временного слоя результатов (Бизнес/День)
        layer_biz = QgsVectorLayer(
            f"{geom_type}?crs={crs}", "Результат_БИЗНЕС_День", "memory"
        )
        pr_biz = layer_biz.dataProvider()
        pr_biz.addAttributes(
            [
                QgsField("Demand_Job", QVariant.Double),
                QgsField("Index_Job", QVariant.Double),
                QgsField("Status", QVariant.String),
            ]
        )
        layer_biz.updateFields()

        self.log("Indexing and caching data...")
        p_idx = QgsSpatialIndex(p_layer.getFeatures())

        p_data = {}
        req_p = QgsFeatureRequest().setSubsetOfAttributes(
            [self.cfg["field_cap"]], p_layer.fields()
        )
        # Кеширование данных парковок
        for f in p_layer.getFeatures(req_p):
            geo = f.geometry()
            if not geo:
                continue
            pt = geo.centroid().asPoint()
            cap = f[self.cfg["field_cap"]]
            cap = float(cap) if cap else 10.0
            p_data[f.id()] = [pt.x(), pt.y(), cap, 0.0, 0.0]

        buildings_cache = []
        req_b = QgsFeatureRequest().setSubsetOfAttributes(
            [self.cfg["field_pop"], self.cfg["field_job"]], b_layer.fields()
        )

        # Кеширование зданий и первичный расчет спроса
        for f in b_layer.getFeatures(req_b):
            geo = f.geometry()
            if not geo:
                continue
            pt = geo.centroid().asPoint()

            pop = float(f[self.cfg["field_pop"]] or 0)
            job = float(f[self.cfg["field_job"]] or 0)

            demand_night_res = pop * self.cfg["auto_rate_res"]
            demand_day_workers = job * self.cfg["auto_rate_job"]
            demand_day_residents = demand_night_res * self.cfg["stay_home_rate"]

            buildings_cache.append(
                {
                    "geom": geo,
                    "cx": pt.x(),
                    "cy": pt.y(),
                    "dem_res": demand_night_res,
                    "dem_job": demand_day_workers,
                    "dem_res_day_competitor": demand_day_residents,
                }
            )

        self.log("Calculating total parking load...")

        # Этап 1: Расчет суммарной нагрузки на каждую парковку (знаменатель модели)
        for b in buildings_cache:
            total_dem = b["dem_res"] + b["dem_job"]
            if total_dem < 0.01:
                continue

            rect = QgsRectangle(
                b["cx"] - self.cfg["radius"],
                b["cy"] - self.cfg["radius"],
                b["cx"] + self.cfg["radius"],
                b["cy"] + self.cfg["radius"],
            )

            for pid in p_idx.intersects(rect):
                if pid not in p_data:
                    continue
                px, py, cap, ln, ld = p_data[pid]

                dist = self.get_distance(
                    QgsPointXY(b["cx"], b["cy"]), QgsPointXY(px, py)
                )

                if dist <= self.cfg["radius"]:
                    w = self.decay_function(dist)
                    # Накопление нагрузки: Ночь
                    p_data[pid][3] += b["dem_res"] * w
                    # Накопление нагрузки: День
                    total_day_demand = b["dem_job"] + b["dem_res_day_competitor"]
                    p_data[pid][4] += total_day_demand * w

        self.log("Generating layers and indices...")

        feats_res = []
        feats_biz = []

        # Этап 2: Расчет индекса обеспеченности для каждого здания
        for b in buildings_cache:
            bx, by = b["cx"], b["cy"]

            # Расчет для жителей (Ночь)
            if b["dem_res"] > 0.1:
                idx_res = 0.0
                rect = QgsRectangle(
                    bx - self.cfg["radius"],
                    by - self.cfg["radius"],
                    bx + self.cfg["radius"],
                    by + self.cfg["radius"],
                )

                for pid in p_idx.intersects(rect):
                    if pid not in p_data:
                        continue

                    px, py, cap, load_night, load_day = p_data[pid]
                    dist = self.get_distance(QgsPointXY(bx, by), QgsPointXY(px, py))

                    if dist <= self.cfg["radius"] and load_night > 0:
                        w = self.decay_function(dist)
                        # Формула доступности: (Емкость * Вес^2) / Нагрузка
                        idx_res += (cap * w * w) / load_night

                f = QgsFeature()
                f.setGeometry(b["geom"])
                stat = (
                    "Норма"
                    if idx_res >= 1.0
                    else ("Дефицит" if idx_res >= 0.5 else "Катастрофа")
                )
                f.setAttributes([b["dem_res"], idx_res, stat])
                feats_res.append(f)

            # Расчет для бизнеса (День)
            if b["dem_job"] > 0.1:
                idx_biz = 0.0
                rect = QgsRectangle(
                    bx - self.cfg["radius"],
                    by - self.cfg["radius"],
                    bx + self.cfg["radius"],
                    by + self.cfg["radius"],
                )

                for pid in p_idx.intersects(rect):
                    if pid not in p_data:
                        continue

                    px, py, cap, load_night, load_day = p_data[pid]
                    dist = self.get_distance(QgsPointXY(bx, by), QgsPointXY(px, py))

                    if dist <= self.cfg["radius"] and load_day > 0:
                        w = self.decay_function(dist)
                        idx_biz += (cap * w * w) / load_day

                f = QgsFeature()
                f.setGeometry(b["geom"])
                stat = (
                    "Норма"
                    if idx_biz >= 1.0
                    else ("Дефицит" if idx_biz >= 0.5 else "Катастрофа")
                )
                f.setAttributes([b["dem_job"], idx_biz, stat])
                feats_biz.append(f)

        # Добавление фич и стилизация слоев
        pr_res.addFeatures(feats_res)
        QgsProject.instance().addMapLayer(layer_res)
        self.apply_style(layer_res, "Index_Res")

        pr_biz.addFeatures(feats_biz)
        QgsProject.instance().addMapLayer(layer_biz)
        self.apply_style(layer_biz, "Index_Job")

        self.log(
            f"Finished. Residents: {len(feats_res)}, Business: {len(feats_biz)}. Time: {time.time() - start_t:.2f} s",
            level=1,
        )

    # Применение градуированного стиля к слою
    def apply_style(self, layer, field_name):
        stops = [
            QgsColorRampShader.ColorRampItem(
                0.0, QColor(215, 25, 28), "Критический дефицит (<0.3)"
            ),
            QgsColorRampShader.ColorRampItem(
                0.5, QColor(253, 174, 97), "Нехватка мест (0.5)"
            ),
            QgsColorRampShader.ColorRampItem(1.0, QColor(166, 217, 106), "Норма (1.0)"),
            QgsColorRampShader.ColorRampItem(
                2.0, QColor(26, 150, 65), "Свободно (>2.0)"
            ),
        ]

        # Определение диапазонов значений для рендерера
        ranges = []
        ranges.append(
            QgsRendererRange(
                -float("inf"),
                0.5,
                self._create_symbol(layer.geometryType(), stops[0].color, 0.9),
                stops[0].label,
            )
        )
        ranges.append(
            QgsRendererRange(
                0.5,
                1.0,
                self._create_symbol(layer.geometryType(), stops[1].color, 0.9),
                stops[1].label,
            )
        )
        ranges.append(
            QgsRendererRange(
                1.0,
                2.0,
                self._create_symbol(layer.geometryType(), stops[2].color, 0.9),
                stops[2].label,
            )
        )
        ranges.append(
            QgsRendererRange(
                2.0,
                float("inf"),
                self._create_symbol(layer.geometryType(), stops[3].color, 0.9),
                stops[3].label,
            )
        )

        renderer = QgsGraduatedSymbolRenderer(field_name, ranges)
        renderer.setMode(QgsGraduatedSymbolRenderer.Custom)
        layer.setRenderer(renderer)
        layer.triggerRepaint()

    # Вспомогательный метод создания символа заливки
    def _create_symbol(self, geom_type: int, color: QColor, opacity: float):
        sym = QgsSymbol.defaultSymbol(geom_type)
        sym.setColor(color)
        sym.setOpacity(opacity)
        if sym.symbolLayer(0):
            sym.symbolLayer(0).setStrokeStyle(0)
        return sym


class ParkingPlugin:
    # Класс интеграции плагина в QGIS
    def __init__(self, iface):
        self.iface = iface
        self.model = ProfessionalParking(CFG)
        self.action = None
        self.menu_label = "Анализ парковок"

    # Инициализация GUI (кнопки, меню)
    def initGui(self):
        self.action = QAction(QIcon(), self.menu_label, self.iface.mainWindow())
        self.action.setToolTip("Run parking analysis")
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Плагины", self.action)

    # Обработчик запуска
    def run(self):
        try:
            self.model.run()
        except Exception as e:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Model Error",
                f"Analysis failed. Check config and layers.\nDetails: {e}",
            )

    # Очистка интерфейса при выгрузке
    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&Плагины", self.action)
            self.iface.removeToolBarIcon(self.action)
