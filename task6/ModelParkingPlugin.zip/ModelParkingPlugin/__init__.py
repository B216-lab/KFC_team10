# Содержимое __init__.py
def classFactory(iface):
    from .mainPlugin import ParkingPlugin

    return ParkingPlugin(iface)
